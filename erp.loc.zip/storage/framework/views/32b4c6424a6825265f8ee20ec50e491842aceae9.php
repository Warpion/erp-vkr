<?php $__env->startSection('title', 'Проекты'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Проекты</h1>
            </div>
            <div class="col-12">
                <a href="<?php echo e(route('projects.create')); ?>" class="button category-button">Добавить Проект</a>
                <ul class="category-list">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="category-item">
                            <a href="<?php echo e(route('projects.edit' , ['project' => $project->id])); ?>">
                                <div class="category-item-content">
                                    <p><?php echo e($project->title); ?></p>
                                    <p><?php echo gmdate('H:i', $project->getTimeSum()) ?></p>
                                </div>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>


            </div>
            <div class="col-12">
                <?php echo e($projects->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/project/index.blade.php ENDPATH**/ ?>