<?php $__env->startSection('title', 'История заданий'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">История заданий: <?php echo e($user->name); ?></h1>
            </div>
            <?php $__currentLoopData = $employeeTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="item-block margin-bottom-30">
                        <span class="area-label">Название</span>
                        <p class="item-p"><?php echo e($task->title); ?></p>
                        <span class="area-label">Результат</span>
                        <p class="item-p"><?php echo e($task->profit); ?></p>
                        <form action="<?php echo e(route('task.deleteResult', [$task->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button class="button margin-0">Удалить результат</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12">
                <?php echo e($employeeTasks->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/dashboard/user/show.blade.php ENDPATH**/ ?>