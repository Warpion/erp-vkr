<?php $__env->startSection('title', 'Выполненные задания'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Выполненные задания</h1>
            </div>
            <div class="col-12">
                <ul>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="single-task-check">
                            <h2 class="task-title"><?php echo e($task->title); ?></h2>
                            <span class="area-label">Тип задания</span>
                            <p class="task-text"><?php echo e($task->category->title); ?></p>
                            <span class="area-label">Описание</span>
                            <p class="task-text"><?php echo e($task->description); ?></p>
                            <span class="area-label">Выполнил</span>
                            <p class="task-text"><?php echo e($task->user->name); ?></p>
                            <form action="<?php echo e(route('task.accept', [$task->id])); ?>" method="post">
                                <?php echo method_field('PATCH'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="button margin-0 button-accept">Приянять выполнение задания</button>
                            </form>
                            <br>
                            <form action="<?php echo e(route('task.decline', [$task->id])); ?>" method="post">
                                <?php echo method_field('PATCH'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="button margin-0">Отказ в выполнении задания</button>
                            </form>
                            <br>
                            <form action="<?php echo e(route('task.restart', [$task->id])); ?>" method="post">
                                <?php echo method_field('PATCH'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="button margin-0 button-hard-decline">Отказать и запустить задание</button>
                            </form>
                            </div>
                        </li>

                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/task/check.blade.php ENDPATH**/ ?>