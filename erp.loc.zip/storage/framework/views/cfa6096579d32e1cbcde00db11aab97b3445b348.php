<?php $__env->startSection('title', "Редактировать проект " . $project->title ); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Редактировать проект: <?php echo e($project->title); ?></h1>
            </div>
            <div class="col-12">
                <div class="edit-form">
                    <div class="edit-form-left">
                        <form method="post" action="<?php echo e(route('project.editProjectStore', [$project->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <label for="title">Название проекта</label>
                            <input id="title" type="text" name="title" value="<?php echo e($project->title); ?>" placeholder="Название проекта" required>
                            <label for="urgency">Приоритет</label>
                            <select id="urgency" name="urgency" placeholder="Приоритет проекта">
                                <option value="1" <?php echo e(($project->urgency === 1) ? 'selected' : ''); ?>>Высокий</option>
                                <option value="2" <?php echo e(($project->urgency === 2) ? 'selected' : ''); ?>>Повышенный</option>
                                <option value="3" <?php echo e(($project->urgency === 3) ? 'selected' : ''); ?>>Обычный</option>
                            </select>
                            <button type="submit" class="button">Изменить проект</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/project/editproject.blade.php ENDPATH**/ ?>