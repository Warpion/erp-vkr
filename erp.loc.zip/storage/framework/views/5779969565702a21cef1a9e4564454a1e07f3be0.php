<?php $__env->startSection('title', 'Задание '.$task->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Задание: <?php echo e($task->title); ?></h1>
            </div>
            <div class="col-12">
                <div class="current-task-item">
                    <span class="area-label">Описание</span>
                    <p class="task-text"><?php echo e($task->description); ?></p>
                    <span class="area-label">Начало выполнения</span>
                    <p class="task-text"><?php if(strlen($start) > 1): ?><?php echo e($start); ?> <?php else: ?> — — — <?php endif; ?></p>
                    <span class="area-label">Вознаграждение</span>
                    <div class="task-price single-task-price">
                        <?php echo e($task->setPrice); ?>

                    </div>
                    <form action="<?php echo e($formAction); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="button margin-0"><?php echo e($buttonContent); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/dashboard/task/show.blade.php ENDPATH**/ ?>