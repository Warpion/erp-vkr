<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('public/styles/bootstrap-grid.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/styles/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/styles/media.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <div class="dark-back"></div>
    <header>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <div class="logo-small">ERP</div>
                    <div class="bars"></div>
                </div>
                <div class="col-md-9">
                    <div class="navigation">
                        <nav>
                            <ul class="menu">
                                <li><a href="<?php echo e(route('dashboard')); ?>">Главная</a></li>
                                <li><a href="<?php echo e(route('dashboard.tasks')); ?>">Задания</a></li>
                                <?php if($role === true): ?>
                                    <li><a href="<?php echo e(route('admin')); ?>">Админ панель</a></li>
                                <?php endif; ?>
                                <li class="mobi-menu-item"><a href="<?php echo e(route('user')); ?>">Личный кабинет</a></li>
                                <li class="mobi-menu-item"><a href="<?php echo e(route('logout')); ?>">Выйти</a></li>
                            </ul>
                        </nav>
                        <a href="<?php echo e(route('user')); ?>" class="hide-768">
                            <div class="user-rating">
                                <img src="<?php echo e(asset('public/img/user/user.png')); ?>" alt="user">
                                <span class="user-score"><?php echo e($user->rating); ?></span>
                            </div>
                        </a>
                        <span class="exit mobi-menu-item"></span>
                        <a href="<?php echo e(route('logout')); ?>" class="button hide-768">Выйти</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <main>
        <a href="<?php echo e(url()->previous()); ?>" class="dashboard-back-url">&#60; Назад</a>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>

    </footer>

    <script src="<?php echo e(asset('public/js/script.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>