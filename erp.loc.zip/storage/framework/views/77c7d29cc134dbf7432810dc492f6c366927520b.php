<?php $__env->startSection('title', 'Личный кабинет'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Личный кабинет</h1>
            </div>
            <div class="col-12">
                <div class="edit-form">
                    <div class="edit-form-left">
                        <form action="<?php echo e(route('user.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <span class="area-label">Имя</span>
                            <input type="text" name="name" value="<?php echo e($user->name); ?>" placeholder="Ваше имя">
                            <span class="area-label">Текущий рейтинг</span>
                            <p class="item-p"><?php echo e($user->rating); ?></p>
                            <button class="button margin-0">Изменить данные</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <h2 class="title margin-top-30">История заданий</h2>
            </div>
            <?php $__currentLoopData = $tasksDone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="item-block margin-bottom-30">
                        <span class="area-label">Название</span>
                        <p class="item-p"><?php echo e($task->title); ?></p>
                        <span class="area-label">Выполнено в</span>
                        <p class="item-p"><?php echo e($task->done_at); ?></p>
                        <span class="area-label">Результат</span>
                        <p class="task-price single-task-price"><?php echo e($task->profit); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12"><?php echo e($tasksDone->links()); ?></div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/user/index.blade.php ENDPATH**/ ?>