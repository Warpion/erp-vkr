<?php $__env->startSection('title', 'Контроль панель'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h1 class="title">Задания</h1>
        </div>
        <div class="col-12">
            <ul class="current-tasks">

                <?php $__currentLoopData = $currentTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li >
                        <a href="<?php echo e(route('taskUser.show', ['id' => $task->taskId])); ?>" class="current-task-link">
                            <div class="current-task-item">
                                <?php if($task->started_at !== null): ?>
                                    <div class="task-in-work">
                                        <img src="<?php echo e(asset('public/img/user/hammers.svg')); ?>" alt="В работе">
                                    </div>
                                <?php endif; ?>
                                <div class="task-item-content">
                                    <div class="task-item-left">
                                        <span class="task-info task-info-title"><?php echo e($task->title); ?></span>
                                        <span class="task-info">Тип задания: <?php echo e($task->ctitle); ?></span>
                                        <span class="task-info">Время выполнения: <?php echo e($task->approxTime); ?></span>
                                    </div>
                                    <div class="task-item-right">
                                        <span class="task-price task-price-<?php echo e($task->urgency); ?>"><?php echo e($task->setPrice); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/dashboard/index.blade.php ENDPATH**/ ?>