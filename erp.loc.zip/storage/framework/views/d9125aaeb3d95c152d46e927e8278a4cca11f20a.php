<?php $__env->startSection('title', "Создание задания" ); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Редактирование задания проекта: <?php echo e($task->title); ?> </h1>
            </div>
            <div class="col-12">
                <?php if($errors->any()): ?>
                    <ul class="error">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="col-12">
                <div class="edit-form">
                    <div class="edit-form-left">
                        <form action="<?php echo e(route('tasks.update', [$id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <label for="title">Название</label>
                            <input type="text" name="title" placeholder="Название" value="<?php echo e($task->title); ?>">
                            <label for="order">Порядок выполнения</label>
                            <input type="number" name="order" placeholder="Порядок выполнения" value="<?php echo e($task->order); ?>">
                            <label for="description">Описание</label>
                            <textarea name="description" cols="50" rows="8" placeholder="Описание"><?php echo e($task->description); ?></textarea>
                            <label for="category_id">Приоритет</label>
                            <select name="category_id" placeholder="Номер категориинщ">
                                <option value="null">Выберите категорию заданий</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php if( $task->category_id == $category->id ): ?> selected <?php endif; ?>>
                                        <?php echo e($category->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="button">Редактировать задание</button>
                        </form>
                        <form action="<?php echo e(route('tasks.destroy', [$id])); ?>" method="post">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="button">Удалить задание</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/task/edit.blade.php ENDPATH**/ ?>