<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Project</title>
</head>
<body>
    <h1><?php echo e($project->title); ?></h1>
    <p>Общее время: <?php echo e($time); ?></p>
    <a href="<?php echo e(route('tasks.create', [$project->id])); ?>">Добавить задание</a>
    <ul>
        <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <h3><?php echo e($task->title); ?></h3>
                <p><?php echo e($task->description); ?></p>
                <p><?php echo e($task->category->time); ?></p>
                <a href="<?php echo e(route('tasks.edit', [$task->id])); ?>">Редактировать</a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

</body>
</html>
<?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/project/show.blade.php ENDPATH**/ ?>