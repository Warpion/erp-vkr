<?php $__env->startSection('title', $project->title ); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title"><?php echo e($project->title); ?></h1>
            </div>
            <div class="col-12">
                <p>Общее время: <?php echo e($time); ?></p>
            </div>
            <div class="col-12">
                <div class="project-buttons">
                    <a href="<?php echo e(route('tasks.create', [$project->id])); ?>" class="button">Добавить задание</a>
                    <a href="<?php echo e(route('project.editProject', [$project->id])); ?>" class="button">Редактировать проект</a>
                    <form action="<?php echo e(route('projects.destroy', [$project])); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="button">Удалить проект со всеми заданиями</button>
                    </form>
                </div>
            </div>
            <div class="col-12">
                <div class="chart-wrapper">
                    <ul class="chart-values">
                        <?php
                            for($i = 0; $i <= $maxTime; $i++) {
                                if(strlen($i) === 1) {
                                    echo "<li>0".strval($i)."</li>";
                                }
                                else {
                                     echo "<li>".strval($i)."</li>";
                                }
                            }

                        ?>
                    </ul>
                    <ul class="chart-bars">

                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-duration="<?php echo e($task['startTime']); ?>-<?php echo e($task['endTime']); ?>" data-color="#33a8a5"><?php echo e($task['title']); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>








                    </ul>
                </div>
            </div>
            <div class="col-12">

                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('tasks.edit', [$task['id']])); ?>">
                    <div class="single-project-task">
                        <h2 class="task-title"><?php echo e($task['title']); ?></h2>
                        <span class="area-label">Описание</span>
                        <p class="task-text"><?php echo e($task['description']); ?></p>
                        <span class="area-label">Время выполнения</span>
                        <p class="task-text"><?php echo gmdate('H:i', $task['time']) ?></p>
                        <span class="more">Подробнее</span>
                    </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/project/edit.blade.php ENDPATH**/ ?>