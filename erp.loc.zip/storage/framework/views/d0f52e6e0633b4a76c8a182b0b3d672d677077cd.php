<?php $__env->startSection('title', "Создание проекта" ); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Создать новый проект</h1>
            </div>
            <div class="col-12">
                <div class="edit-form">
                    <div class="edit-form-left">
                        <form action="<?php echo e(route('projects.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="title">Название проекта</label>
                            <input id="title" type="text" name="title" placeholder="Название проекта" required>
                            <label for="urgency">Приоритет</label>
                            <select id="urgency" name="urgency" placeholder="Приоритет проекта">
                                <option value="1">Высокий</option>
                                <option value="2">Повышенный</option>
                                <option value="3" selected>Обычный</option>
                            </select>
                            <button type="submit" class="button">Создать новый проект</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/project/create.blade.php ENDPATH**/ ?>