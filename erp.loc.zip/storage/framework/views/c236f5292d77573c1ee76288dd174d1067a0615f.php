<?php $__env->startSection('title', 'Список сотрудников'); ?>

<?php $__env->startSection('content'); ?>
   <div class="container">
       <div class="row">
           <div class="col-12">
               <h1 class="title">Список сотрудников</h1>
           </div>
           <?php $__currentLoopData = $usersList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-md-6">
                   <a href="<?php echo e(route('user.admin.show', ['id' => $userItem->id])); ?>" class="user-link">
                       <div class="item-block margin-bottom-30">
                           <p class="item-p"><?php echo e($userItem->name); ?></p>
                           <span class="area-label">Текущий рейтинг</span>
                           <p class="item-p"><?php echo e($userItem->rating); ?></p>
                           <span class="button margin-0">Подробнее</span>
                       </div>
                   </a>
               </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12"><?php echo e($usersList->links()); ?></div>
       </div>
   </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/dashboard/user/users.blade.php ENDPATH**/ ?>