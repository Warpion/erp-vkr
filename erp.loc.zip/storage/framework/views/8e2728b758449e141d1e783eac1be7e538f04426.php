<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Регистрация</title>
</head>
<body>
    <h1>Регистрация</h1>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <br>
    <form action="<?php echo e(route('user.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail">
        <br><br>
        <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Имя">
        <br><br>
        <input type="password" name="password">
        <br><br>
        <input type="password" name="password_confirmation">
        <br><br>
        <button type="submit">Зарегистрироваться</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/register/create.blade.php ENDPATH**/ ?>