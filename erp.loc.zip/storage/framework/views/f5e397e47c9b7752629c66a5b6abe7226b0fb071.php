<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('public/styles/bootstrap-grid.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/styles/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/styles/media.css')); ?>">
    <title>Авторизация</title>
</head>
<body>
<div class="container-fluid welcome-container">
    <div class="row g-0">
        <a href="<?php echo e(url()->previous()); ?>" class="back-url">&#60; Назад</a>
        <div class="col-12 welcome-block">
            <?php if($errors->any()): ?>
                <ul class="error">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <form action="<?php echo e(route('login')); ?>" method="POST" class="login-form">
                <?php echo csrf_field(); ?>
                <h1>Авторизация</h1>
                <label for="email">E-mail</label>
                <input id="email" type="email" name="email" placeholder="E-mail">
                <label for="password">Пароль</label>
                <input id="password" type="password" name="password" placeholder="Пароль">
                <button type="submit" class="button">Войти</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/auth/login.blade.php ENDPATH**/ ?>