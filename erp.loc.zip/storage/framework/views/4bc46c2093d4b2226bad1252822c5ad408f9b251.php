<?php $__env->startSection('title', "Редактировать группу " . $category->title ); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Редактировать группу  <?php echo e($category->title); ?></h1>
            </div>
            <div class="col-12">
                <div class="edit-form">
                    <div class="edit-form-left">
                        <form action="<?php echo e(route('categories.update', [$category])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <label for="title">Название группы</label>
                            <input id="title" type="text" name="title" value="<?php echo e($category->title); ?>" placeholder="Название группы">
                            <label for="price">Вознаграждение</label>
                            <input id="price" type="number" name="price" value="<?php echo e($category->price); ?>" placeholder="Вознаграждение">
                            <label for="rating">Навык сотрудника</label>
                            <input id="rating" type="number" name="rating" value="<?php echo e($category->rating); ?>" placeholder="Навык сотрудника">
                            <label for="max_rating">Максимальный навык</label>
                            <input id="max_rating" type="number" name="max_rating" value="<?php echo e($category->max_rating); ?>" placeholder="Максимальный навык">
                            <label for="time">Время выполнения</label>
                            <input id="time" type="time" name="time" value="<?php echo e($category->time); ?>">
                            <button type="submit" class="button">Изменить категорию</button>
                        </form>
                        <form action="<?php echo e(route('categories.destroy', [$category])); ?>" method="post">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="button">Удалить категорию со всеми заданиями</button>
                        </form>
                    </div>
                    <div class="edit-form-right">
                        <span class="area-label">Всего выполненно</span>
                        <p class="task-text"><?php echo e($category->tasks_complete); ?></p>
                        <span class="area-label">Среднее время</span>
                        <p class="task-text"><?php echo e(gmdate("H:i", $category->time_avg)); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/category/edit.blade.php ENDPATH**/ ?>