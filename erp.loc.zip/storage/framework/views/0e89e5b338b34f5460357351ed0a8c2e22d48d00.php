<?php $__env->startSection('title', 'Админ панель'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Группы заданий</h1>
            </div>
            <div class="col-12">
                <a href="<?php echo e(route('categories.create')); ?>" class="button category-button">Создать группу</a>
                <ul class="category-list">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="category-item">
                            <a href="<?php echo e(route('categories.edit', [$category->id])); ?>">
                            <div class="category-item-content">
                                <p><?php echo e($category->title); ?></p>
                                <p><?php echo e($category->time); ?></p>
                                <span class="cat-edit">Редактировать</span>
                            </div>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-12">
                <?php echo e($categories->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/category/index.blade.php ENDPATH**/ ?>