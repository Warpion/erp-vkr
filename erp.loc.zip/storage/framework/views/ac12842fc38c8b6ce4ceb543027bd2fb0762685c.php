<?php $__env->startSection('title', "Создание задания" ); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="title">Добавление задания к проекту: <?php echo e($projectTitle); ?></h1>
            </div>
            <div class="col-12">
                <?php if($errors->any()): ?>
                    <ul class="error">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="col-12">
                <div class="edit-form">
                    <div class="edit-form-left">
                        <form action="<?php echo e(route('tasks.store', ['id' => $id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="title">Название</label>
                            <input id="title" type="text" name="title" placeholder="Название" value="<?php echo e(old('title')); ?>">
                            <input type="hidden" name="project_id" value="<?php echo e($id); ?>">
                            <label for="order">Порядок выполнения</label>
                            <input id="order" type="number" name="order" placeholder="Порядок выполнения" value="0">
                            <label for="description">Описание</label>
                            <textarea id="description" name="description" cols="50" rows="8" placeholder="Описание"><?php echo e(old('description')); ?></textarea>
                            <label for="user_id">Исполнитель</label>
                            <select id="user_id" name="user_id" placeholder="Номер категориинщ">
                                <option value="" selected>Выберите исполнителя</option>
                                <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>">
                                        <?php echo e($employee->name.' '.$employee->rating); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="category_id">Приоритет</label>
                            <select id="category_id" name="category_id" placeholder="Номер категориинщ">
                                <option value="null" selected>Выберите категорию заданий</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>">
                                        <?php echo e($category->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="button">Добавить задание</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Warpi\Desktop\openserver\OpenServer\domains\erp.loc\resources\views/task/add.blade.php ENDPATH**/ ?>